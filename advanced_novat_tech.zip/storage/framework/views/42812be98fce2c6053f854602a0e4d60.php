<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Manage Permissions</h1>
    <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createPermissionModal">
        <i class="fas fa-plus me-2"></i>Create New Permission
    </button>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Permissions Overview -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card stats-card success">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title text-muted">Total Permissions</h6>
                        <h3 class="mb-0"><?php echo e($permissions->count()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-key fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stats-card primary">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title text-muted">Permission Groups</h6>
                        <h3 class="mb-0"><?php echo e($grouped_permissions->count()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-layer-group fa-2x text-primary"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stats-card warning">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title text-muted">Assigned to Roles</h6>
                        <h3 class="mb-0"><?php echo e($permissions->sum('roles_count')); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-user-tag fa-2x text-warning"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Grouped Permissions -->
<?php $__currentLoopData = $grouped_permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $groupPermissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="row mb-4">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">
                    <i class="fas fa-folder me-2"></i><?php echo e(ucfirst($group)); ?> Permissions
                    <span class="badge bg-secondary ms-2"><?php echo e($groupPermissions->count()); ?></span>
                </h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>Permission Name</th>
                                <th>Guard</th>
                                <th>Roles Count</th>
                                <th>Users Count</th>
                                <th>Created Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $groupPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <span class="badge bg-info"><?php echo e($permission->name); ?></span>
                                </td>
                                <td><?php echo e($permission->guard_name); ?></td>
                                <td><?php echo e($permission->roles_count); ?></td>
                                <td><?php echo e($permission->users_count); ?></td>
                                <td><?php echo e($permission->created_at->format('M d, Y')); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                            onclick="editPermission(<?php echo e($permission->id); ?>, '<?php echo e($permission->name); ?>', '<?php echo e($permission->guard_name); ?>')"
                                            data-bs-toggle="modal" data-bs-target="#editPermissionModal">
                                        <i class="fas fa-edit"></i> Edit
                                    </button>
                                    <?php if($permission->roles_count == 0 && $permission->users_count == 0): ?>
                                    <form action="<?php echo e(route('admin.access-control.permissions.destroy', $permission)); ?>" 
                                          method="POST" class="d-inline" 
                                          onsubmit="return confirm('Are you sure you want to delete this permission?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-sm btn-outline-danger">
                                            <i class="fas fa-trash"></i> Delete
                                        </button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if($grouped_permissions->count() == 0): ?>
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-body text-center">
                <i class="fas fa-key fa-3x text-muted mb-3"></i>
                <h5>No Permissions Found</h5>
                <p class="text-muted">Create your first permission to get started.</p>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#createPermissionModal">
                    <i class="fas fa-plus me-2"></i>Create Permission
                </button>
            </div>
        </div>
    </div>
</div>
<?php endif; ?>

<!-- Create Permission Modal -->
<div class="modal fade" id="createPermissionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="<?php echo e(route('admin.access-control.permissions.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Create New Permission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="name" class="form-label">Permission Name</label>
                        <input type="text" class="form-control" id="name" name="name" required 
                               placeholder="e.g., users-create, products-edit, orders-view">
                        <small class="form-text text-muted">
                            Use kebab-case format with group prefix (e.g., users-create, products-edit)
                        </small>
                    </div>
                    <div class="mb-3">
                        <label for="guard_name" class="form-label">Guard Name</label>
                        <select class="form-control" id="guard_name" name="guard_name" required>
                            <option value="web">Web</option>
                            <option value="api">API</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create Permission</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Edit Permission Modal -->
<div class="modal fade" id="editPermissionModal" tabindex="-1">
    <div class="modal-dialog">
        <div class="modal-content">
            <form id="editPermissionForm" method="POST">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Edit Permission</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="edit_name" class="form-label">Permission Name</label>
                        <input type="text" class="form-control" id="edit_name" name="name" required>
                        <small class="form-text text-muted">
                            Use kebab-case format with group prefix (e.g., users-create, products-edit)
                        </small>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Permission</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
function editPermission(id, name, guardName) {
    document.getElementById('edit_name').value = name;
    document.getElementById('editPermissionForm').action = `/admin/access-control/permissions/${id}`;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\advanced_novat_tech\resources\views/admin/access-control/permissions.blade.php ENDPATH**/ ?>