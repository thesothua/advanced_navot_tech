<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\advanced_novat_tech\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>