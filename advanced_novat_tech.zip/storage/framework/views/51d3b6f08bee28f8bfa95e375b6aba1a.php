<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">User Permissions Management</h1>
</div>

<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show" role="alert">
        <?php echo e(session('success')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
        <?php echo e(session('error')); ?>

        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    </div>
<?php endif; ?>

<!-- Users Overview -->
<div class="row mb-4">
    <div class="col-md-4">
        <div class="card stats-card primary">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title text-muted">Total Users</h6>
                        <h3 class="mb-0"><?php echo e($users->total()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-users fa-2x text-primary"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stats-card success">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title text-muted">Available Roles</h6>
                        <h3 class="mb-0"><?php echo e($roles->count()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-user-tag fa-2x text-success"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stats-card warning">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h6 class="card-title text-muted">Available Permissions</h6>
                        <h3 class="mb-0"><?php echo e($permissions->count()); ?></h3>
                    </div>
                    <div class="align-self-center">
                        <i class="fas fa-key fa-2x text-warning"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Users List -->
<div class="row">
    <div class="col-md-12">
        <div class="card">
            <div class="card-header">
                <h5 class="card-title mb-0">Users & Their Permissions</h5>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover">
                        <thead>
                            <tr>
                                <th>User</th>
                                <th>Email</th>
                                <th>Roles</th>
                                <th>Direct Permissions</th>
                                <th>Joined</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="avatar-sm bg-primary rounded-circle d-flex align-items-center justify-content-center me-2">
                                            <span class="text-white"><?php echo e(strtoupper(substr($user->name, 0, 1))); ?></span>
                                        </div>
                                        <strong><?php echo e($user->name); ?></strong>
                                    </div>
                                </td>
                                <td><?php echo e($user->email); ?></td>
                                <td>
                                    <?php $__empty_2 = true; $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <span class="badge bg-primary me-1"><?php echo e($role->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span class="text-muted">No roles</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                        $directPermissions = $user->getDirectPermissions();
                                    ?>
                                    <?php $__empty_2 = true; $__currentLoopData = $directPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_2 = false; ?>
                                        <span class="badge bg-info me-1"><?php echo e($permission->name); ?></span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_2): ?>
                                        <span class="text-muted">No direct permissions</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($user->created_at->format('M d, Y')); ?></td>
                                <td>
                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                            onclick="manageUserRoles(<?php echo e($user->id); ?>, '<?php echo e($user->name); ?>')"
                                            data-bs-toggle="modal" data-bs-target="#userRolesModal">
                                        <i class="fas fa-user-tag"></i> Roles
                                    </button>
                                    <button type="button" class="btn btn-sm btn-outline-info" 
                                            onclick="manageUserPermissions(<?php echo e($user->id); ?>, '<?php echo e($user->name); ?>')"
                                            data-bs-toggle="modal" data-bs-target="#userPermissionsModal">
                                        <i class="fas fa-key"></i> Permissions
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">No users found</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                
                <!-- Pagination -->
                <div class="d-flex justify-content-center">
                    <?php echo e($users->links()); ?>

                </div>
            </div>
        </div>
    </div>
</div>

<!-- User Roles Modal -->
<div class="modal fade" id="userRolesModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form id="userRolesForm" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title">Manage Roles for <span id="user-name-roles"></span></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6">
                            <div class="form-check">
                                <input class="form-check-input user-role-check" type="checkbox" 
                                       value="<?php echo e($role->id); ?>" 
                                       id="user_role_<?php echo e($role->id); ?>" 
                                       name="roles[]">
                                <label class="form-check-label" for="user_role_<?php echo e($role->id); ?>">
                                    <?php echo e($role->name); ?>

                                    <small class="text-muted d-block"><?php echo e($role->permissions->count()); ?> permissions</small>
                                </label>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Update Roles</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- User Permissions Modal -->
<div class="modal fade" id="userPermissionsModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Manage Direct Permissions for <span id="user-name-permissions"></span></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
            </div>
            <div class="modal-body">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i>
                    These are direct permissions assigned to the user, separate from role-based permissions.
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-6">
                        <h6>Available Permissions</h6>
                        <div class="border rounded p-3" style="max-height: 300px; overflow-y: auto;">
                            <div id="available-permissions">
                                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="permission-item mb-2 p-2 border rounded">
                                    <span class="badge bg-secondary"><?php echo e($permission->name); ?></span>
                                    <button type="button" class="btn btn-xs btn-outline-success ms-2" 
                                            onclick="assignPermission(<?php echo e($permission->id); ?>, '<?php echo e($permission->name); ?>')">
                                        <i class="fas fa-plus"></i> Assign
                                    </button>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <h6>User's Direct Permissions</h6>
                        <div class="border rounded p-3" style="max-height: 300px; overflow-y: auto;">
                            <div id="user-permissions-list">
                                <!-- Will be populated by JavaScript -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<style>
.avatar-sm {
    width: 32px;
    height: 32px;
    font-size: 0.8rem;
}
.permission-item {
    background-color: #f8f9fa;
}
</style>

<script>
let currentUserId = null;

function manageUserRoles(userId, userName) {
    currentUserId = userId;
    document.getElementById('user-name-roles').textContent = userName;
    document.getElementById('userRolesForm').action = `/admin/access-control/users/${userId}/sync-roles`;
    
    // Clear all checkboxes first
    document.querySelectorAll('.user-role-check').forEach(cb => cb.checked = false);
    
         // Fetch user roles and check appropriate boxes
     fetch(`/admin/access-control/users/${userId}/roles-permissions`, {
         headers: {
             'Accept': 'application/json',
             'X-Requested-With': 'XMLHttpRequest'
         }
     })
         .then(response => response.json())
         .then(data => {
             data.roles.forEach(roleId => {
                const checkbox = document.getElementById(`user_role_${roleId}`);
                if (checkbox) {
                    checkbox.checked = true;
                }
            });
        })
        .catch(error => console.error('Error:', error));
}

function manageUserPermissions(userId, userName) {
    currentUserId = userId;
    document.getElementById('user-name-permissions').textContent = userName;
    
         // Fetch and display user's direct permissions
     fetch(`/admin/access-control/users/${userId}/roles-permissions`, {
         headers: {
             'Accept': 'application/json',
             'X-Requested-With': 'XMLHttpRequest'
         }
     })
         .then(response => response.json())
        .then(data => {
            const permissionsList = document.getElementById('user-permissions-list');
            permissionsList.innerHTML = '';
            
            if (data.direct_permissions.length === 0) {
                permissionsList.innerHTML = '<p class="text-muted">No direct permissions assigned</p>';
            } else {
                data.direct_permissions.forEach(permissionId => {
                    const permission = <?php echo json_encode($permissions, 15, 512) ?>.find(p => p.id === permissionId);
                    if (permission) {
                        const permissionDiv = document.createElement('div');
                        permissionDiv.className = 'permission-item mb-2 p-2 border rounded';
                        permissionDiv.innerHTML = `
                            <span class="badge bg-info">${permission.name}</span>
                            <button type="button" class="btn btn-xs btn-outline-danger ms-2" 
                                    onclick="revokePermission(${permission.id}, '${permission.name}')">
                                <i class="fas fa-minus"></i> Revoke
                            </button>
                        `;
                        permissionsList.appendChild(permissionDiv);
                    }
                });
            }
        })
        .catch(error => console.error('Error:', error));
}

function assignPermission(permissionId, permissionName) {
    if (!currentUserId) return;
    
    const formData = new FormData();
    formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
    formData.append('permission_id', permissionId);
    
                   fetch(`/admin/access-control/users/${currentUserId}/permissions`, {
          method: 'POST',
          headers: {
              'Accept': 'application/json',
              'X-Requested-With': 'XMLHttpRequest'
          },
          body: formData
      })
      .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Refresh the permissions list
            manageUserPermissions(currentUserId, document.getElementById('user-name-permissions').textContent);
        }
    })
    .catch(error => console.error('Error:', error));
}

function revokePermission(permissionId, permissionName) {
    if (!currentUserId) return;
    
    if (!confirm(`Are you sure you want to revoke the "${permissionName}" permission?`)) {
        return;
    }
    
    const formData = new FormData();
    formData.append('_token', document.querySelector('meta[name="csrf-token"]').getAttribute('content'));
    formData.append('permission_id', permissionId);
    
                   fetch(`/admin/access-control/users/${currentUserId}/permissions`, {
          method: 'DELETE',
          headers: {
              'Accept': 'application/json',
              'X-Requested-With': 'XMLHttpRequest'
          },
          body: formData
      })
      .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Refresh the permissions list
            manageUserPermissions(currentUserId, document.getElementById('user-name-permissions').textContent);
        }
    })
    .catch(error => console.error('Error:', error));
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\advanced_novat_tech\resources\views/admin/access-control/user-permissions.blade.php ENDPATH**/ ?>